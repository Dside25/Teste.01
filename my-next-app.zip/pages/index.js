export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Olá, mundo! 🚀</h1>
      <p>Este é um exemplo de app Next.js pronta para deploy no Vercel.</p>
      <img src="/logo.png" alt="Logo" width={150} />
    </div>
  );
}
